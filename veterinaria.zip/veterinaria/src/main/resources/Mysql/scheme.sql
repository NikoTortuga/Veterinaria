CREATE DATABASE IF NOT EXISTS veterinaria;
 use veterinaria;


-- Eliminar tablas al iniciar segun relaciones

DROP TABLE IF EXISTS datos_ventas;
DROP TABLE IF EXISTS ventas;
DROP TABLE IF EXISTS productos;
DROP TABLE IF EXISTS mascotas;
DROP TABLE IF EXISTS clientes;
DROP TABLE IF EXISTS empleados;


CREATE TABLE clientes (
    id_clientes INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    dni INT(20),
    telefono VARCHAR(20),
    correo VARCHAR(100)
);

CREATE TABLE empleados (
    id_empleados INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    dni VARCHAR(20) NOT NULL,
    telefono VARCHAR(20) NOT NULL,
    correo VARCHAR(100)
);

CREATE TABLE productos (
    id_productos INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    precio DECIMAL(10,2) NOT NULL,
    stock INT,
    descripción VARCHAR(1000)
);

CREATE TABLE mascotas (
    id_mascotas INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    especie VARCHAR(100) NOT NULL,
    raza VARCHAR(100) NOT NULL,
    edad_estimada VARCHAR(100) NOT NULL,
    oberservaciones VARCHAR(1000),
    id_clientes INT NOT NULL,
    FOREIGN KEY (id_clientes) REFERENCES clientes(id_clientes)
);

CREATE TABLE ventas (
    id_ventas INT AUTO_INCREMENT PRIMARY KEY,
    fecha DATETIME DEFAULT CURRENT_TIMESTAMP,
    id_empleados INT NOT NULL,
    id_clientes INT,
    monto_total DECIMAL (10,2),
    FOREIGN KEY (id_empleados) REFERENCES empleados(id_empleados),
    FOREIGN KEY (id_clientes) REFERENCES clientes(id_clientes)
);

CREATE TABLE datos_ventas (
    PRIMARY KEY(id_ventas),
    id_ventas INT,
    id_productos INT,
    cantidad INT,
    FOREIGN KEY (id_ventas) REFERENCES ventas(id_ventas),
    FOREIGN KEY (id_productos) REFERENCES productos(id_productos)
);
