USE freedb_veterinaria;

-- Clientes frecuentes:
SELECT c.nombre,
    c.apellido,
    COUNT(v.id_venta) AS cantidad_compras
FROM ventas v
    JOIN clientes c ON v.id_cliente = c.id_cliente
GROUP BY c.id_cliente
HAVING COUNT(v.id_venta) > 1
ORDER BY cantidad_compras DESC;

-- Mascotas, su dueño y quien lo atendio:
SELECT
m.nombre AS mascota,
m.especie,
c.nombre AS duenio,
c.apellido AS apellido_duenio,
e.nombre AS empleado,
e.apellido AS apellido_empleado
FROM mascotas m 
JOIN clientes c ON m.id_cliente = c.id_cliente
JOIN ventas v ON v.id_cliente = c.id_cliente
JOIN empleados e ON v.id_empleado = e.id_empleado
GROUP BY m.id_mascota, e.id_empleado
ORDER BY duenio;

-- Productos mas vendidos:
 SELECT p.nombre AS producto,
 SUM(dv.cantidad) AS total_vendido,
 p.precio,
 SUM (dv.cantidad * p.precio) AS ganancia_total
 FROM datos_ventas dv
 JOIN productos p ON dv.id_producto = p.id_producto
 GROUP BY p.id_producto
 HAVING total_vendido >2
 ORDER BY total_vendido DESC;

-- Ganancia total por venta de empleado:
SELECT 
e.nombre,
e.apellido,
SUM(v.monto_total) AS total_facturado
FROM ventas v
JOIN empleados e ON v.id_empleado = e.id_empleado
GROUP BY e.id_empleado
ORDER BY total_facturado DESC;

-- Dias con mas ventas:

SELECT 
 DATE(fecha) AS dia,
 COUNT(*) AS cantidad_ventas
 FROM ventas
 GROUP BY dia
 ORDER BY cantidad_ventas DESC
 LIMIT 10;
