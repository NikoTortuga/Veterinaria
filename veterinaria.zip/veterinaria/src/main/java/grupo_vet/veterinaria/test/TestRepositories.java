package grupo_vet.veterinaria.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import java.math.BigDecimal;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.List;

import grupo_vet.veterinaria.entities.Cliente;
import grupo_vet.veterinaria.entities.DatosVenta;
import grupo_vet.veterinaria.entities.Empleado;
import grupo_vet.veterinaria.entities.Mascota;
import grupo_vet.veterinaria.entities.Producto;
import grupo_vet.veterinaria.entities.Venta;
import grupo_vet.veterinaria.repositories.*;
import grupo_vet.veterinaria.repositories.interfaces.*;

// La clase TestRepositories obtiene los DAOs y ejecuta operaciones para asegurar que funcionen
// antes de crear el GUI

// Se pone @Repository en los DAOs para que spring detecte que son objetos gestianados por Spring

// El scan indica a Spring Boot que revise todos los componentes, crear y configurar
// todas las piezas de la aplicación

@SpringBootApplication(scanBasePackages = "grupo_vet.veterinaria")

public class TestRepositories {
    public static void main(String[] args) {

        try (ConfigurableApplicationContext context = SpringApplication.run(TestRepositories.class, args);) {
            I_ClienteRepository clienteRepository = context.getBean(ClienteRepository.class);
            I_DatosVentaRepository datosVentaRepository = context.getBean(DatosVentaRepository.class);
            I_EmpleadoRepository empleadoRepository = context.getBean(EmpleadoRepository.class);
            I_MascotaRepository mascotaRepository = context.getBean(MascotaRepository.class);
            I_ProductoRepository productoRepository = context.getBean(ProductoRepository.class);
            I_VentaRepository ventaRepository = context.getBean(VentaRepository.class);

            // ************************** Pruebas de cliente

            // Test 1: Crear un cliente

            System.out.println("\nTEST 1: CREATE CLIENTE");
            Cliente cliente = new Cliente(0, "Camila", "Rodríguez", "45678901", "1165432198", "camila.rod@gmail.com");
            clienteRepository.create(cliente);
            System.out.println("Cliente creado con ID: " + cliente.getIdCliente());

            System.out.println("\nTEST 2: FIND CLIENTE BY ID");
            System.out.println(clienteRepository.findById(cliente.getIdCliente()));

            System.out.println("\nTEST 3: FIND ALL CLIENTES");
            clienteRepository.findAll().forEach(System.out::println);

            System.out.println("\nTEST 4: UPDATE CLIENTE");
            cliente.setNombre("Camila Soledad");
            cliente.setCorreo("camila.soledad@gmail.com");
            clienteRepository.update(cliente);
            System.out.println("Cliente actualizado: " + clienteRepository.findById(cliente.getIdCliente()));

            System.out.println("\nTEST 5: DELETE CLIENTE");
            clienteRepository.delete(cliente.getIdCliente());
            System.out.println("Estado:" + clienteRepository.findById(cliente.getIdCliente()));

            // ************************** Pruebas de datos venta

            System.out.println("\nTEST 6: CREATE DATOSVENTA");
            DatosVenta nuevaDV = new DatosVenta(1, 3, 4);
            try {
                datosVentaRepository.create(nuevaDV);
                System.out.println("DatosVenta creado: " + nuevaDV);
            } catch (SQLException e) {
                System.err.println("No se pudo crear DatosVenta: " + e.getMessage());
            }

            System.out.println("\nTEST 7: FIND ALL DATOSVENTA");
            datosVentaRepository.findAll().forEach(System.out::println);

            System.out.println("\nTEST 8: FIND BY ID_VENTA = 3");
            List<DatosVenta> porVenta = datosVentaRepository.findByIdVenta(3);
            porVenta.forEach(System.out::println);

            System.out.println("\nTEST 9: FIND BY ID_PRODUCTO = 4");
            List<DatosVenta> porProducto = datosVentaRepository.findByIdProducto(4);
            porProducto.forEach(System.out::println);

            System.out.println("\nTEST 10: UPDATE DATOSVENTA (venta=3, producto=4)");
            DatosVenta dvUpdate = new DatosVenta(3, 4, 10);
            int filasUpdate = datosVentaRepository.update(dvUpdate);
            System.out.println("Cantidad de filas actualizadas: " + filasUpdate);
            datosVentaRepository.findByIdVenta(3).forEach(System.out::println);

            System.out.println("\nTEST 11: DELETE DATOSVENTA");
            int filasDelete = datosVentaRepository.delete(3, 4);
            System.out.println("Cantidad de filas eliminadas: " + filasDelete);

            // ************************** Pruebas de empleado

            System.out.println("\nTEST 12: CREATE EMPLEADO");
            Empleado nuevoEmpleado = new Empleado(0, "Romina", "Silva", "99887766", "1199223344",
                    "romina.silva@mail.com");
            empleadoRepository.create(nuevoEmpleado);
            System.out.println("Empleado creado con ID: " + nuevoEmpleado.getIdEmpleado());

            System.out.println("\nTEST 13: FIND EMPLEADO BY ID");
            Empleado empleadoBuscado = empleadoRepository.findById(nuevoEmpleado.getIdEmpleado());
            System.out.println(empleadoBuscado);

            System.out.println("\nTEST 14: FIND ALL EMPLEADOS");
            empleadoRepository.findAll().forEach(System.out::println);

            System.out.println("\nTEST 15: UPDATE EMPLEADO");
            nuevoEmpleado.setTelefono("1177112233");
            nuevoEmpleado.setCorreo("romina.actualizado@mail.com");
            empleadoRepository.update(nuevoEmpleado);
            System.out.println("Actualizado:");
            System.out.println(empleadoRepository.findById(nuevoEmpleado.getIdEmpleado()));

            System.out.println("\nTEST 16: DELETE EMPLEADO");
            int filasEliminadas = empleadoRepository.delete(nuevoEmpleado.getIdEmpleado());
            System.out.println("Filas eliminadas: " + filasEliminadas);

            // ************************** Pruebas de mascota

            System.out.println("\nTEST 17: CREATE MASCOTA");
            Mascota nuevaMascota = new Mascota(0, "Chispita", "Perro", "Caniche", "2 años", "Muy juguetona", 1);
            mascotaRepository.create(nuevaMascota);
            System.out.println("Mascota creada con ID: " + nuevaMascota.getIdMascota());

            System.out.println("\nTEST 18: FIND BY ID MASCOTA");
            List<Mascota> mascotasPorId = mascotaRepository.findByIdMascota(nuevaMascota.getIdMascota());
            mascotasPorId.forEach(System.out::println);
  
            System.out.println("\nTEST 19: FIND ALL MASCOTAS");
            mascotaRepository.findAll().forEach(System.out::println);

            System.out.println("\nTEST 20: FIND BY ID_CLIENTE = 1");
            mascotaRepository.findByIdCliente(1).forEach(System.out::println);

            System.out.println("\nTEST 21: UPDATE MASCOTA");
            nuevaMascota.setEdadEstimada("3 años");
            nuevaMascota.setObservaciones("Vacunada y desparasitada");
            mascotaRepository.update(nuevaMascota);
            System.out.println("Actualizado:");
            mascotaRepository.findByIdMascota(nuevaMascota.getIdMascota()).forEach(System.out::println);

  

            // ************************** Pruebas de producto

            System.out.println("\nTEST 24: CREATE PRODUCTO");
            Producto nuevoProducto = new Producto(0, "Vitaminas Caninas", new BigDecimal("1500.00"), 25,
                    "Vitaminas para perros activos");
            productoRepository.create(nuevoProducto);
            System.out.println("Producto creado con ID: " + nuevoProducto.getIdProducto());

            System.out.println("\nTEST 25: FIND PRODUCTO BY NOMBRE");
            List<Producto> productosPorNombre = productoRepository.findByNombre("Vitaminas");
            productosPorNombre.forEach(System.out::println);

            System.out.println("\nTEST 26: FIND ALL PRODUCTOS");
            productoRepository.findAll().forEach(System.out::println);

            System.out.println("\nTEST 27: UPDATE PRODUCTO");
            nuevoProducto.setPrecio(new BigDecimal("1800.00"));
            nuevoProducto.setStock(30);
            nuevoProducto.setDescripcion("Vitaminas reforzadas para perros activos");
            productoRepository.update(nuevoProducto);
            System.out.println("Producto actualizado:");
            System.out.println(productoRepository.findByNombre("Vitaminas Caninas").get(0));

  

            // ************************** Pruebas de venta

            System.out.println("\nTEST 29: CREATE VENTA");
            Venta nuevaVenta = new Venta(0, LocalDateTime.now(), 1, 2, new BigDecimal("3500.00"));
            ventaRepository.create(nuevaVenta);
            System.out.println("Venta creada con ID: " + nuevaVenta.getIdVenta());

            System.out.println("\nTEST 30: FIND VENTA BY ID");
            Venta ventaEncontrada = ventaRepository.findById(nuevaVenta.getIdVenta());
            System.out.println(ventaEncontrada);

            System.out.println("\nTEST 31: FIND VENTAS BY ID CLIENTE (ID = 2)");
            ventaRepository.findByIdCliente(2).forEach(System.out::println);

            System.out.println("\nTEST 32: FIND VENTAS BY ID EMPLEADO (ID = 1)");
            ventaRepository.findByIdEmpleado(1).forEach(System.out::println);

            System.out.println("\nTEST 33: UPDATE VENTA");
            nuevaVenta.setMontoTotal(new BigDecimal("3900.00"));
            ventaRepository.update(nuevaVenta);
            System.out.println("Venta actualizada:");
            System.out.println(ventaRepository.findById(nuevaVenta.getIdVenta()));


            // ************************** Excepcion en caso de error

        } catch (Exception e) {
            System.err.println("Error en la base de datos");
            e.printStackTrace();
        }

    }
}
