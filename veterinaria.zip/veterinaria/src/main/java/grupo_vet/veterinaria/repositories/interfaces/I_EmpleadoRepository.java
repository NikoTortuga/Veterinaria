package grupo_vet.veterinaria.repositories.interfaces;

import grupo_vet.veterinaria.entities.Empleado;

import java.sql.SQLException;
import java.util.List;


public interface I_EmpleadoRepository {
void create (Empleado empleado) throws SQLException;
Empleado findById(int Id) throws SQLException;
List<Empleado> findAll () throws SQLException;
int update (Empleado empleado) throws SQLException;
int delete (int id) throws SQLException;
}
