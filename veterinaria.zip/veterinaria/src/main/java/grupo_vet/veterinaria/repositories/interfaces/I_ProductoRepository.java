package grupo_vet.veterinaria.repositories.interfaces;

import grupo_vet.veterinaria.entities.Producto;

import java.sql.SQLException;
import java.util.List;


public interface I_ProductoRepository {
void create (Producto producto) throws SQLException;
List<Producto> findAll() throws SQLException;
List<Producto> findByNombre(String nombre) throws SQLException;
int update (Producto producto) throws SQLException;
int delete(int id) throws SQLException;
}
