package grupo_vet.veterinaria.repositories.interfaces;

import grupo_vet.veterinaria.entities.Mascota;

import java.sql.SQLException;
import java.util.List;

public interface I_MascotaRepository {
void create(Mascota mascota) throws SQLException;
List<Mascota> findAll() throws SQLException;
List<Mascota> findByIdMascota(int idMascota) throws SQLException;
List<Mascota> findByIdCliente(int idCLiente) throws SQLException;
int update(Mascota mascota) throws SQLException;
int delete (int id) throws SQLException;
}

