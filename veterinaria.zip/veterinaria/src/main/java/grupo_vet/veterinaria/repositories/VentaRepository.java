package grupo_vet.veterinaria.repositories;
import grupo_vet.veterinaria.entities.Venta;
import grupo_vet.veterinaria.repositories.interfaces.I_VentaRepository;

import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.stereotype.Repository;

@Repository

public class VentaRepository implements I_VentaRepository {

    private final DataSource dataSource;

    private static final String SQL_CREATE =
        "INSERT INTO ventas (fecha, id_empleado, id_cliente, monto_total) VALUES (?, ?, ?, ?)";

    private static final String SQL_FIND_BY_ID =
        "SELECT * FROM ventas WHERE id_venta = ?";

    private static final String SQL_FIND_ALL =
        "SELECT * FROM ventas";

    private static final String SQL_FIND_BY_ID_CLIENTE =
        "SELECT * FROM ventas WHERE id_cliente = ?";

    private static final String SQL_FIND_BY_ID_EMPLEADO =
        "SELECT * FROM ventas WHERE id_empleado = ?";

    private static final String SQL_UPDATE =
        "UPDATE ventas SET fecha = ?, id_empleado = ?, id_cliente = ?, monto_total = ? WHERE id_venta = ?";

    private static final String SQL_DELETE =
        "DELETE FROM ventas WHERE id_venta = ?";

    public VentaRepository(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    @Override
    public void create(Venta venta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_CREATE, Statement.RETURN_GENERATED_KEYS)) {

            ps.setTimestamp(1, Timestamp.valueOf(venta.getFecha()));
            ps.setInt(2, venta.getIdEmpleado());
            ps.setInt(3, venta.getIdCliente());
            ps.setBigDecimal(4, venta.getMontoTotal());
            ps.executeUpdate();

            try (ResultSet keys = ps.getGeneratedKeys()) {
                if (keys.next()) {
                    venta.setIdVenta(keys.getInt(1));
                }
            }
        }
    }

    @Override
    public Venta findById(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID)) {

            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        }
        return null;
    }

    @Override
    public List<Venta> findAll() throws SQLException {
        List<Venta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_ALL);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                lista.add(mapRow(rs));
            }
        }
        return lista;
    }

    @Override
    public List<Venta> findByIdCliente(int idCliente) throws SQLException {
        List<Venta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_CLIENTE)) {

            ps.setInt(1, idCliente);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public List<Venta> findByIdEmpleado(int idEmpleado) throws SQLException {
        List<Venta> lista = new ArrayList<>();
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_FIND_BY_ID_EMPLEADO)) {

            ps.setInt(1, idEmpleado);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(mapRow(rs));
                }
            }
        }
        return lista;
    }

    @Override
    public int update(Venta venta) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_UPDATE)) {

            ps.setTimestamp(1, Timestamp.valueOf(venta.getFecha()));
            ps.setInt(2, venta.getIdEmpleado());
            ps.setInt(3, venta.getIdCliente());
            ps.setBigDecimal(4, venta.getMontoTotal());
            ps.setInt(5, venta.getIdVenta());
            return ps.executeUpdate();
        }
    }

    @Override
    public int delete(int id) throws SQLException {
        try (Connection conn = dataSource.getConnection();
             PreparedStatement ps = conn.prepareStatement(SQL_DELETE)) {

            ps.setInt(1, id);
            return ps.executeUpdate();
        }
    }

    private Venta mapRow(ResultSet rs) throws SQLException {
        Venta venta = new Venta();
        venta.setIdVenta(rs.getInt("id_venta"));
        venta.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
        venta.setIdEmpleado(rs.getInt("id_empleado"));
        venta.setIdCliente(rs.getInt("id_cliente"));
        venta.setMontoTotal(rs.getBigDecimal("monto_total"));
        return venta;
    }
}