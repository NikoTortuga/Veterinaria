package grupo_vet.veterinaria.entities;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Venta {
    private int idVenta;
    private LocalDateTime fecha;
    private int idEmpleado;
    private int idCliente;
    private BigDecimal montoTotal;
}
