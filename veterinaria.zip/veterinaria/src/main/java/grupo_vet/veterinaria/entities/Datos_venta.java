package grupo_vet.veterinaria.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Datos_venta {
    private int id_venta;
    private int id_producto;
    private int cantidad;
}
