package grupo_vet.veterinaria.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class Mascota {
    private int idMascota;
    private String nombre;
    private String especie;
    private String raza;
    private String edadEstimada;
    private String observaciones;
    private int idCliente;
};

