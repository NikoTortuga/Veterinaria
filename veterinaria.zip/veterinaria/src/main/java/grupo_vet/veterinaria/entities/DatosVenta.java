package grupo_vet.veterinaria.entities;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor

public class DatosVenta {
    private int idVenta;
    private int idProducto;
    private int cantidad;
}
